<?php
    session_start();
    if(isset($_COOKIE['sesh'])){
        session_decode($_COOKIE['sesh']);
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>SKATE HUB</title>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
	<link href="../../css/stylo.css" rel="stylesheet">
	<link href="../../assets/favicon2.png" rel="icon" type="image/png">
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Kufam&display=swap" rel="stylesheet">
</head>
<body>

    <header>

        <?php

            require_once("../../funciones/funciones.php");

            echo"
                <div>
                    <div class='parallaxD'>
                    
                        <div class='container1'>
                        
                            <div class='container2'>
                                <div id='opening'>
                                    <div>
                                        <h1 id='titulo1'> DEPORTISTAS </h1>
                                        <img src='../../assets/skatelogo3.png'>
                                    </div>
                                </div>
                            </div>

                        </div>
                    
                    </div>

                </div>
                
            ";
            
        ?>

    </header>

    <main>

        <?php

            menu();

                echo"

                    <div class='container my-5' align='center'>
                        <form id='form_insertar' action='../../controladores/deportista/añadir_deportista.php' method='POST' enctype='multipart/form-data'>

                            <div class='mb-3'>
                                <label for='dni' class='form-label'></label>
                                <input type='text' class='form-control' id='dni' name='dni' placeholder='DNI' required>
                            </div>
                            <br>
                            <div class='mb-3'>
                                <label for='nombre' class='form-label'></label>
                                <input type='text' class='form-control' id='nombre' name='nombre' placeholder='Nombre' required>
                            </div>
                            <br>
                            <div class='mb-3'>
                                <label for='apellido' class='form-label'></label>
                                <input type='text' class='form-control' id='apellido' name='apellido' placeholder='Apellido' required>
                            </div>
                            <br>
                            <div class='mb-3'>
                                <label for='usuario' class='form-label'></label>
                                <input type='text' class='form-control' name='usuario' id='usuario' placeholder='Nombre usuario' required>
                            </div>
                            <br>
                            <div class='mb-3'>
                                <label for='contraseña' class='form-label'></label>
                                <input type='password' class='form-control' id='contraseña' name='contraseña' placeholder='Contraseña' required>
                            </div>
                            <br>
                            <div class='mb-3'>
                                <label for='telefono' class='form-label'></label>
                                <input type='text' class='form-control' id='telefono' name='telefono' placeholder='Número de contacto'>
                            </div>
                            <br>
                            <div class='mb-3'>
                                <label for='fecha' class='form-label'>Fecha de nacimiento</label>
                                <input type='date' class='form-control' name='fecha' id='fecha' required>
                            </div>
                            <br>
                            <div class='mb-3'>
                                <label for='imagen' class='form-label'>placeholder='Foto de perfil'</label>
                                <input type='file' class='form-control' id='imagen' name='imagen' >
                            </div>
                            <br>
                            <input type='submit' class='btn btn-primary' name='enviar' value='enviar'>

                        </form>
                    </div>
                ";
            
        ?>
        
    </main>

    <?php

        footer();

    ?>

</body>
</html>