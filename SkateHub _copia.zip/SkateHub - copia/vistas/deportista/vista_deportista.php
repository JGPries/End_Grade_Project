<?php
    session_start();
    if(isset($_COOKIE['sesh'])){
        session_decode($_COOKIE['sesh']);
    }
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>SKATE HUB</title>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
	<link href="../../css/stylo.css" rel="stylesheet">
	<link href="../../assets/favicon2.png" rel="icon" type="image/png">
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Kufam&display=swap" rel="stylesheet">
</head>

<body>

    <header>

        <?php

            require_once("../../funciones/funciones.php");

            
            echo"
                <div>
                    <div class='parallaxD'>
                    
                        <div class='container1'>
                        
                            <div class='container2'>
                                <div id='opening'>
                                    <div>
                                        <h1 id='titulo1'> DEPORTISTAS </h1>
                                        <img src='../../assets/skatelogo3.png'>
                                    </div>
                                </div>
                            </div>

                        </div>
                    
                    </div>

                </div>
                    
            ";

            

        ?>

    </header>

    <main>

        <?php

            menu();

            if(isset($_SESSION['cif'])){

                require_once("../../controladores/deportista/controlador_deportista.php");

                if(isset($datos)){

                    echo"<div class='container'>
                            <div class='row'>       
                    ";

                    foreach($datos as $dato){

                        echo"

                        <div class='col-3 p-3'>
                            <div class='cartaPlataforma'>       
                                    
                                <div class='card my-5'>
                                    
                                    <img src='../../assets/imagenes/$dato[foto]' class='img-fluid' class='w-25'>
                                    
                                    <div class='card-body'>
                                        <h4>$dato[nombre]</h4>
                                        <h4>$dato[apellido]</h4>
                                        <p>".convertir_fecha($dato['fecha'])."</p>
                                    </div>
                                </div>
                                            
                            </div>
                        </div>
                        ";

                    }
                    echo"</div></div>";

                }else{

                    echo"
                        <div>
                            <h2>No hay deportistas actualmente</h2>
                        </div>";

                }

            }elseif(isset($_SESSION['dni'])){

                require_once("../../controladores/deportista/controlador_deportista.php");

                if(isset($datos)){

                    echo"<div class='container'>
                            <div class='row'>       
                    ";

                    foreach($datos as $dato){

                        echo"

                        <div class='col-3 p-3'>
                            <div class='cartaPlataforma'>       
                                    
                                <div class='card my-5'>
                                    
                                    <img src='../../assets/imagenes/$dato[foto]' class='img-fluid' class='w-25'>
                                    
                                    <div class='card-body'>
                                        <h4>$dato[nombre]</h4>
                                        <h4>$dato[apellido]</h4>
                                        <p>".convertir_fecha($dato['fecha'])."</p>
                                    </div>
                                </div>
                                            
                            </div>
                        </div>
                        ";

                    }
                    echo"</div></div>";

                }else{

                    echo"
                        <div>
                            <h2>No hay deportistas actualmente</h2>
                        </div>";

                }

            }else{

                require_once("../../controladores/deportista/controlador_deportista.php");

                if(isset($datos)){

                    echo"<div class='container'>
                            <div class='row'>       
                    ";

                    foreach($datos as $dato){

                        echo"

                        <div class='col-3 p-3'>
                            <div class='cartaPlataforma'>       
                                    
                                <div class='card my-5'>
                                    
                                    <img src='../../assets/imagenes/$dato[foto]'  class='img-fluid'  >
                                    
                                    <div class='card-body'>
                                        <h4>$dato[nombre]</h4>
                                        <h4>$dato[apellido]</h4>
                                        <p>".convertir_fecha($dato['fecha'])."</p>
                                    </div>
                                </div>
                                            
                            </div>
                        </div>
                        ";

                    }
                    echo"</div></div>";

                }else{

                    echo"
                        <div>
                            <h2>No hay deportistas actualmente</h2>
                        </div>";

                }

            }

        ?>
        
    </main>

    <?php

        footer();

    ?>
</body>
</html>