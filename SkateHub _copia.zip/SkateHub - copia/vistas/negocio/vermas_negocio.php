<?php
    session_start();
    if(isset($_COOKIE['sesh'])){
        session_decode($_COOKIE['sesh']);
    }
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>SKATE HUB</title>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
	<link href="../../css/stylo.css" rel="stylesheet">
	<link href="../../assets/favicon2.png" rel="icon" type="image/png">
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Kufam&display=swap" rel="stylesheet">
</head>
<body>
    
    <header>

        <?php

            require_once("../../funciones/funciones.php");

            $parametro1="";
			$parametro2="../../vistas/";

            echo"
                <div>
                    <div class='parallaxN'>
                    
                        <div class='container1'>
                        
                            <div class='container2'>
                                <div id='opening'>
                                    <div>
                                        <h1 id='titulo1'> NEGOCIOS </h1>
                                        <img src='../../assets/skatelogo3.png'>
                                    </div>
                                </div>
                            </div>

                        </div>
                    
                    </div>

                </div>
                    
            ";

		?>

    </header>

    <main>

    <?php

        menu($parametro1,$parametro2);

        if(isset($_SESSION['cif'])){


            if(isset($ver)){

                echo"
             
                    <div class='card my-5' align='center'>
                        
                        <img src='../../assets/imagenes/$ver[foto]' class='img-fluid my-5' >
                        
                        <div class='card-body'>
                            <h1>$ver[nombre]</h1>
                            <p>$ver[tipo]</p>
                            
                        </div>
                    </div>
             
                ";

                // Eventos del negocio

                if(isset($event)){

                    echo"<div class='diveventos'>
                            <div class='row'>       
                    ";

                    foreach($event as $eventos){

                        echo"

                        <div class='col-6'>
                                 
                            <div class='card my-5' class='w-50'>
                                
                                <img src='../../assets/imagenes/$eventos[foto]' class='img-fluid' >
                                
                                <div class='card-body'>
                                    <h4>$eventos[nombre]</h4>
                                    <p>".convertir_fecha($eventos['fecha'])."</p>
                                </div>
                            </div>
                               
                        </div>
                        ";

                    }
                    echo"</div></div>";

                }else{

                    echo"
                        <div>
                            <h2>No hay eventos actualmente</h2>
                        </div>";

                }

            }
            
        }elseif(isset($_SESSION['dni'])){

            if(isset($ver)){

                echo"
             
                    <div class='card my-5' align='center'>
                        
                        <img src='../../assets/imagenes/$ver[foto]' class='img-fluid my-5' >
                        
                        <div class='card-body'>
                            <h1>$ver[nombre]</h1>
                            <p>$ver[tipo]</p>
                            
                        </div>
                    </div>
             
                ";

                // Eventos del negocio

                if(isset($event)){

                    echo"<div class='diveventos'>
                            <div class='row'>       
                    ";

                    foreach($event as $eventos){

                        echo"

                        <div class='col-6'>     
                                    
                            <div class='card my-5' class='w-50'>
                                
                                <img src='../../assets/imagenes/$eventos[foto]' class='img-fluid' >
                                
                                <div class='card-body'>
                                    <h4>$eventos[nombre]</h4>
                                    <p>".convertir_fecha($eventos['fecha'])."</p>
                                </div>
                            </div>
                             
                        </div>
                        ";

                    }
                    echo"</div></div>";

                }else{

                    echo"
                        <div>
                            <h2>No hay eventos actualmente</h2>
                        </div>";

                }
            }

        }else{

            echo"
                    <div class='warning my-5' align='center'>

                        <h1 id='titulo1'>
                            ERROR INESPERADO.
                        </h1>

                        <h1 id='titulo1'>
                            VOLVIENDO AL INICIO.
                        </h1>

                        <h1 id='titulo1'>
                            PERDONE LAS MOLESTIAS :)
                        </h1>

                        <img src='../../assets/gif_pausa1.gif'>

                    </div>
                ";

                echo "<meta http-equiv='refresh' content='7;url=../../index.php'>";

        }



    ?>

    </main>

    <?php

        footer();

    ?>
</body>
</html>
