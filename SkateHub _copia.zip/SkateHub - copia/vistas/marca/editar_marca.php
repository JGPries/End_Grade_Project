<?php
    session_start();
    if(isset($_COOKIE['sesh'])){
        session_decode($_COOKIE['sesh']);
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>SKATE HUB</title>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
	<link href="../../css/stylo.css" rel="stylesheet">
	<link href="../../assets/favicon2.png" rel="icon" type="image/png">
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Kufam&display=swap" rel="stylesheet">
</head>
<body>

    <header>

        <?php

            require_once("../../funciones/funciones.php");

            echo"
                <div id='divTitular'>
                    <div>
                        <h1 id='titulos'> EDITAR DATOS PERSONALES </h1>
                        <img src='../../assets/skatelogo3.png' alt='' width='60' height='54'>
                    </div>
                </div>
                
            ";

        ?>

    </header>

    <main>

        <?php

            menu();

            if(!isset($_SESSION['usuario'])){

                header("location:../../../index.php");

            }elseif($_SESSION['usuario']!='admin'){

                require_once "../../controladores/negocio/editar_negocio.php";

                if(isset($editacion)){

                    echo"

                        <div class='container'>
                            <form id='form_insertar' action='../../controladores/negocio/negocio_editado.php' method='POST' enctype='multipart/form-data'>

                                <div class='mb-3'>
                                    <label for='nombre' class='form-label'></label>
                                    <input type='text' class='form-control' placeholder='Nombre' name='nombre' id='nombre' value='$editacion[nombre]'>
                                </div>
                                <br>
                                <div class='mb-3'>
                                    <label for='usuario' class='form-label'></label>
                                    <input type='text' class='form-control' placeholder='Nombre de usuario' name='usuario' id='usuario' value='$editacion[usuario]'>
                                </div>
                                <br>
                                <div class='mb-3'>
                                    <label for='contraseña' class='form-label'></label>
                                    <input type='password' class='form-control' placeholder='Contraseña' id='contraseña' name='contraseña' value='$editacion[contraseña]'>
                                </div>
                                <br>
                                <div class='mb-3'>
                                    <label for='telefono' class='form-label'></label>
                                    <input type='text' class='form-control' placeholder='Número de contacto' id='telefono' name='telefono' value='$editacion[telefono]'>
                                </div>
                                <br>
                                    <div class='mb-3'>
                                    <label for='foto' class='form-label'></label>
                                    <input type='text' class='form-control' placeholder='Logotipo del negocio' id='foto' name='foto' value='$editacion[foto]'>
                                </div>
                                <br>
                                <input type='submit' class='btn btn-primary' name='enviar' value='enviar'>
                                <input type='hidden' name='cif' value='$editacion[cif]'>
                            </form>
                        </div>
                    ";

                }
            }
            
        ?>
        
    </main>

    <?php

        footer();

    ?>

</body>
</html>