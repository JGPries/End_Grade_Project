<?php

    //Cabeceras
    header('Content-Type: application/json');
    header("Access-Control-Allow-Origin: *");
    require_once("../../modelo/conexionjs.php");

    $conexion=conectar();

    $datos=[];
    $sentencia=$conexion->query("SELECT * FROM marca");
        
    while($fila=$sentencia->fetch_assoc()){ 
            $datos[]=$fila;
    }

    echo json_encode($datos);    

?>