<!-- <?php

    header('Content-Type: application/json');
    header("Access-Control-Allow-Origin: *");
    require_once("../../modelo/conexionjs.php");
  
    $conexion=conectar();

    //EL IF ES PARA PROBARLO A MANO
    //EN TEORIA EL FORMULARIO COMPRUEBA QUE LOS DATOS SON CORRECTOS 

    if(isset($_REQUEST['logotipo']) && isset($_REQUEST['nombre'])){

        $foto = $_REQUEST['logotipo'];
        $nombre = $_REQUEST['nombre'];

        if ($foto[]>0) {

            if (!file_exists("../../assets/imagenes")) {
                mkdir("../../assets/imagenes");
            }

            if ($foto["type"]==="image/jpeg") {
                $logotipo=$nombre.".jpg";
            }elseif ($foto["type"]==="image/png") {
                $logotipo=$nombre.".png";
            }
        
            $ruta="../../assets/imagenes/$logotipo";

            move_uploaded_file ($foto['tmp_name'],$ruta);

        }

        // $logotipo = $_REQUEST['logotipo'];
        // $nombre = $_REQUEST['nombre'];
        

        $sentencia=$conexion->prepare("INSERT INTO 
                                            marca 
                                            VALUES (null, ?,?)");
        $sentencia->bind_param("ss",$logotipo,$nombre);
        
        $sentencia->execute();
        $filas_afectadas = $sentencia->affected_rows;
        
        if($filas_afectadas == 1){

            echo "$conexion->insert_id";

        }else{

            echo "false";
        
        }
        
    }else{
        
        echo "false";
    
    }

?> -->