<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>SKATE HUB</title>
    <script type="text/javascript" src="../../js/api_externa.js" defer ></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
	<link href="../../css/stylo.css" rel="stylesheet">
	<link href="../../assets/favicon2.png" rel="icon" type="image/png">
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Kufam&display=swap" rel="stylesheet">
</head>
<body>

    <header>

        <?php

			require_once("../../funciones/funciones.php");

            echo"
                <div>
                    <div class='parallaxA'>
                    
                        <div class='container1'>
                        
                            <div class='container2'>
                                <div id='opening'>
                                    <div>
                                        <h1 id='titulo1'> ACCESO </h1>
                                        <img src='../../assets/skatelogo3.png'>
                                    </div>
                                </div>
                            </div>

                        </div>
                    
                    </div>

                </div>
                    
            ";

		?>

    </header>

    <main>
    
        <?php

            menu();

            echo"
            
                <div id='f_accesos'>
                    
                    <div class='container'>
                        

                        <form id='form_acceder' action='../../controladores/sesiones/control_acceso_deportistas.php' method='POST'>
                        
                            <h1 id='titulo2'> DEPORTISTAS </h1>

                            <div class='mb-3'>
                                <label for='dni' class='form-label'></label>
                                <input type='text' class='form-control' placeholder='DNI' id='dni' name='dni' required>
                            </div>
                            <br>
                            <div class='mb-3'>
                                <label for='contraseña' class='form-label'></label>
                                <input type='password' class='form-control' placeholder='Contraseña' id='contraseña' name='contraseña' required>
                            </div>
                            <br>    
                            <div class='mb-3'>               
                                <input type='checkbox' name='bloquear'> Mantener la sesión
                            </div>
                            <br>
                            <input type='submit' value='Iniciar sesión' name='enviarDepor' class='boton3'>
                            
                        </form>
                    </div> 

                    <div class='container'>
                        

                        <form id='form_acceder' action='../../controladores/sesiones/control_acceso_negocios.php' method='POST'>
                        
                            <h1 id='titulo2'> NEGOCIOS </h1>

                            <div class='mb-3'>
                                <label for='cif' class='form-label'></label>
                                <input type='text' class='form-control' placeholder='CIF' id='cif' name='cif' required>
                            </div>
                            <br>
                            <div class='mb-3'>
                                <label for='contraseña' class='form-label'></label>
                                <input type='password' class='form-control' placeholder='Contraseña' id='contraseña' name='contraseña' required>
                            </div>
                            <br>    
                            <div class='mb-3'>               
                                <input type='checkbox' name='bloquear'> Mantener la sesión
                            </div>
                            <br>
                            <input type='submit' value='Iniciar sesión' name='enviarNego' class='boton3'>
                            
                        </form>
                    </div> 

                </div>
            ";

            echo"

                <div class='container3'>
                    
                    <a href='../deportista/insertar_deportista.php' class='boton4'> <h4> Crear cuenta como deportista </h4> </a>
                    <a href='../negocio/insertar_negocio.php' class='boton4'> <h4> Crear cuenta como negocio </h4> </a>
            
                </div>
            
            ";

        ?>

        <hr>
        <div class="container" id="galeriaExt">
      
        </div>
        <div id="chuckdance" align='center'>
            <img src='../../assets/chuckdance.gif'>
        </div>
        
    </main>

    <?php

        footer();

    ?>

</body>
</html>