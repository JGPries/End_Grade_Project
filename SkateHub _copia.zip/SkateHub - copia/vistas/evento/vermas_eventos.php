<?php
    session_start();
    if(isset($_COOKIE['sesh'])){
        session_decode($_COOKIE['sesh']);
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>SKATE HUB</title>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
	<link href="../../css/stylo.css" rel="stylesheet">
	<link href="../../assets/favicon2.png" rel="icon" type="image/png">
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Kufam&display=swap" rel="stylesheet">
</head>

<body>

    <header>

        <?php

            require_once("../../funciones/funciones.php");

            $parametro1="";
			$parametro2="../../vistas/";
			
            
            echo"
                <div>
                    <div class='parallaxE'>
                    
                        <div class='container1'>
                        
                            <div class='container2'>
                                <div id='opening'>
                                    <div>
                                        <h1 id='titulo1'> EVENTOS </h1>
                                        <img src='../../assets/skatelogo3.png'>
                                    </div>
                                </div>
                            </div>

                        </div>
                    
                    </div>

                </div>
                    
            ";

        ?>

    </header>

    <main>

        <?php

            menu($parametro1,$parametro2);

            if(isset($_SESSION['cif'])){

                if(isset($ver)){

                    echo"
      
                        <div class='card my-5' align='center'>
                            
                            <img src='../../assets/imagenes/$ver[foto]'  class='img-fluid my-5' >
                            
                            <div class='card-body'>
                                <h4>$ver[nombre]</h4>
                                <p>$ver[descripción]</p>
                                <p>".convertir_fecha($ver['fecha'])."</p>
                            </div>
                        </div>
             
                    ";

                    // Para mostrar las listas de participantes

                    if(isset($listas)){

                        echo"
                            <div class='tablita'>
                                <div>
                                
                                    <table class=' text-center table table-dark table-striped'>
                                        <thead>
                                            <tr>
                                                <th scope='col'>Nombre</th>
                                                <th scope='col'>Apellido</th>
                                                <th scope='col'>Puntuación</th>
                                            </tr>
                                        </thead>
                        ";
                            
                        foreach($listas as $lista){

                            echo"
                                <tbody>
                                    <tr class='listas_insc'>
                                        <td>$lista[nom_dep]</td>
                                        <td>$lista[apell_dep]</td>
                                        <td>$lista[puntu]</td>
                                    </tr>
                                </tbody>
                            ";   

                        }
                        echo"</table></div></div>";

                    }

                }

            }elseif(isset($_SESSION['dni'])){

                if(isset($ver)){

                    echo"
      
                        <div class='card my-5' align='center'>
                            
                            <img src='../../assets/imagenes/$ver[foto]'  class='img-fluid my-5' >
                            
                            <div class='card-body'>
                                <h4>$ver[nombre]</h4>
                                <p>$ver[descripción]</p>
                                <p>".convertir_fecha($ver['fecha'])."</p>
                            </div>
                        </div>
             
                    ";

                    // Para mostrar el botón si el evento es antes del dia de hoy.
                        $today=date('Y-m-d');
                        if($ver['fecha']>$today){

                            echo"

                                <div class='container my-5' align='center'>

                                    <form action='../../controladores/inscripciones/inscribirse.php' method='POST'>

                                        <input type='hidden' name='dni' value='$_SESSION[dni]'>

                                        <input type='hidden' name='evento' value='$ver[codigo]'>
                                            
                                        <input type='submit' class='boton1' name='insc' value='Inscribirse'>

                                    </form>

                                </div>

                            ";

                        }
                        
                    // Para mostrar las listas de participantes

                    if(isset($listas)){

                        echo"
                            <div class='tablita'>
                                <div>
                                
                                    <table class=' text-center table table-dark table-striped'>
                                        <thead>
                                            <tr>
                                                <th scope='col'>Nombre</th>
                                                <th scope='col'>Apellido</th>
                                                <th scope='col'>Puntuación</th>
                                            </tr>
                                        </thead>
                        ";
                            
                        foreach($listas as $lista){

                            echo"
                                <tbody>
                                    <tr class='listas_insc'>
                                        <td>$lista[nom_dep]</td>
                                        <td>$lista[apell_dep]</td>
                                        <td>$lista[puntu]</td>
                                    </tr>
                                </tbody>
                            ";   

                        }
                        echo"</table></div></div>";

                    }

                }

            }else{

                if(isset($ver)){

                    echo"
      
                        <div class='card my-5' align='center'>
                            
                            <img src='../../assets/imagenes/$ver[foto]'  class='img-fluid my-5' >
                            
                            <div class='card-body'>
                                <h4>$ver[nombre]</h4>
                                <p>$ver[descripción]</p>
                                <p>".convertir_fecha($ver['fecha'])."</p>
                            </div>
                        </div>
             
                    ";
                }
            }

        ?>
        
    </main>

    <?php

        footer();

    ?>
</body>
</html>