<?php
    session_start();
    if(isset($_COOKIE['sesh'])){
        session_decode($_COOKIE['sesh']);
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>SKATE HUB</title>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
	<link href="../../css/stylo.css" rel="stylesheet">
	<link href="../../assets/favicon2.png" rel="icon" type="image/png">
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Kufam&display=swap" rel="stylesheet">
</head>
<body>

    <header>

        <?php

            require_once("../../funciones/funciones.php");

            echo"
                <div>
                    <div class='parallaxE'>
                    
                        <div class='container1'>
                        
                            <div class='container2'>
                                <div id='opening'>
                                    <div>
                                        <h1 id='titulo1'> EDITAR EVENTOS </h1>
                                        <img src='../../assets/skatelogo3.png'>
                                    </div>
                                </div>
                            </div>

                        </div>
                    
                    </div>

                </div>
                    
            ";

        ?>

    </header>

    <main>

        <?php

            menu();

            if(isset($_SESSION['cif'])){

                echo"
                    <div id='divTitular'>
                        <div>
                            <h1 id='titulos'> EDITAR EVENTO </h1>
                        </div>
                    </div>
					
				";

                require_once "../../controladores/evento/controlador_editar_evento.php";

                if(isset($editacion)){

                    echo"

                        <div class='container my-5' align='center'>
                            <form id='form_insertar' action='../../controladores/evento/evento_editado.php' method='POST' enctype='multipart/form-data'>
                                
                                <div class='mb-3'>
                                    <img src='../../assets/imagenes/$editacion[foto]' class='card-img-top' class='img-fluid'>
                                </div>
                                <br>
                                <div class='mb-3'>
                                    <label for='nombre' class='form-label'>Nombre</label>
                                    <input type='text' class='form-control' id='nombre' name='nombre' value='$editacion[nombre]'>
                                </div>
                                <br>
                                <div class='mb-3'>
                                    <label for='descripcion' class='form-label'>Descripción</label>
                                    <input type='text' class='form-control' name='descripcion' id='descripcion' value='$editacion[descripción]'>
                                </div>
                                <br>
                                <input type='submit' class='btn btn-primary' name='editevent' value='enviar'>
                                <input type='hidden' name='codigo' value='$editacion[codigo]'>
                                <input type='hidden' name='cif' value='$editacion[cif]'>
                                <input type='hidden' name='foto' value='$editacion[foto]'>
                            </form>
                        </div>
                    ";

                }
                
                // Para mostrar las listas de participantes

                if(isset($lists)){

                    echo"
                        <div class='tablita'>
                            <div>
                            
                                <table class=' text-center table table-dark table-striped'>
                                    <thead>
                                        <tr>
                                            <th scope='col'>Nombre</th>
                                            <th scope='col'>Apellido</th>
                                            <th scope='col'>Puntuación</th>
                                            <th scope='col'></th>
                                        </tr>
                                    </thead>
                    ";
                        
                    foreach($lists as $list){

                        echo"
                            <tbody>
                                <tr class='listas_insc'>
                                    <td>$list[nom_dep]</td>
                                    <td>$list[apell_dep]</td>
                                    <td>$list[puntu]</td>
                                    <td>
                                        <form action='../../controladores/inscripciones/editar_lista.php' method='POST' >
                                            <input type='submit' value='editar' name='inscmod' class='btn btn-success'>
                                            <input type='hidden' value='$list[dnii]' name='inscedit'>
                                            <input type='hidden' value='$list[codigoo]' name='evenedit'>
                                        </form>
                                    </td>
                                </tr>
                            </tbody>
                        ";   

                    }
                    echo"</table></div></div>";

                }

            }else{
             
                echo"
                    <div class='warning my-5' align='center'>

                        <h1 id='titulo1'>
                            ERROR INESPERADO.
                        </h1>

                        <h1 id='titulo1'>
                            VOLVIENDO AL INICIO.
                        </h1>

                        <h1 id='titulo1'>
                            PERDONE LAS MOLESTIAS :)
                        </h1>

                        <img src='../../assets/gif_pausa1.gif'>

                    </div>
                ";

                echo "<meta http-equiv='refresh' content='7;url=../../index.php'>";
                
            }
        ?>
        
    </main>

    <?php

        footer();

    ?>

</body>
</html>