-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 04-06-2022 a las 19:37:14
-- Versión del servidor: 10.4.22-MariaDB
-- Versión de PHP: 7.4.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `skatehub`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `deportista`
--

CREATE TABLE `deportista` (
  `dni` bigint(8) NOT NULL,
  `nombre` varchar(50) CHARACTER SET latin1 COLLATE latin1_spanish_ci NOT NULL,
  `apellido` varchar(50) CHARACTER SET latin1 COLLATE latin1_spanish_ci NOT NULL,
  `usuario` varchar(50) CHARACTER SET latin1 COLLATE latin1_spanish_ci NOT NULL,
  `contraseña` varchar(20) CHARACTER SET latin1 COLLATE latin1_spanish_ci NOT NULL,
  `telefono` int(12) NOT NULL,
  `fecha` date NOT NULL,
  `foto` varchar(1000) CHARACTER SET latin1 COLLATE latin1_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `deportista`
--

INSERT INTO `deportista` (`dni`, `nombre`, `apellido`, `usuario`, `contraseña`, `telefono`, `fecha`, `foto`) VALUES
(2855714, 'Tommy', 'Sandoval', 'tommy', 'tommy', 547772, '1989-03-11', 'Tommy.jpg'),
(11893425, 'Ishod', 'Wair', 'ishod', 'ishod', 4198541, '1995-11-02', 'Ishod.jpg'),
(19283765, 'Homer', 'Simp', 'homer', 'homer', 1463, '2022-05-06', 'Homer.png'),
(84637583, 'Luan', 'Oliveira', 'luan', 'luan', 54754, '1994-09-18', 'Luan.jpg');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `evento`
--

CREATE TABLE `evento` (
  `codigo` bigint(9) NOT NULL,
  `cif` bigint(9) NOT NULL,
  `nombre` varchar(50) CHARACTER SET latin1 COLLATE latin1_spanish_ci NOT NULL,
  `foto` varchar(1000) NOT NULL,
  `descripción` varchar(1000) CHARACTER SET latin1 COLLATE latin1_spanish_ci NOT NULL,
  `fecha` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `evento`
--

INSERT INTO `evento` (`codigo`, `cif`, `nombre`, `foto`, `descripción`, `fecha`) VALUES
(6, 91827364, 'Girls Skate Night', 'Girls Skate Night.jpg', 'Competición freestyle para todas las edades en el escombro diy de Madrid y presentación del nuevo video de Tiago Lemos.', '2018-05-05'),
(7, 11925764, 'DACKS', 'DACKS.jpg', 'Competición open street y bowl en el Rincón de la Victoria. Comenzando con las clasificatorias de ambas partes y finalizando con la final de street y después bowl.', '2022-10-11'),
(8, 30456434, 'Campeonato Cádiz Skate', 'Campeonato Cádiz Skate.jpg', 'Open Street en Cádiz, La Marina Sur el 21-22-23 de junio. Primer día de clasificatorias. El 22 serán las semifinales y la gran final. El 23 cerraremos con una gran comida familiar y conciertos.', '2014-06-21'),
(9, 49895673, 'V.E.S.O', 'V.E.S.O.jpg', 'Open Street en Valencia, La Marina Sur el 5-6-7 de noviembre. Primer día de clasificatorias. El 6 serán las semifinales y la gran final. El 7 cerraremos con una gran comida familiar y conciertos.', '2022-11-05'),
(10, 91827364, 'Skate Camp', 'Skate Camp.jpg', 'Campamento de skate de verano abierto a todo el mundo.', '2021-07-15');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `inscribe`
--

CREATE TABLE `inscribe` (
  `dni` bigint(8) NOT NULL,
  `evento` bigint(9) NOT NULL,
  `puntuacion` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `inscribe`
--

INSERT INTO `inscribe` (`dni`, `evento`, `puntuacion`) VALUES
(2855714, 7, 0),
(2855714, 9, 0),
(11893425, 7, 0),
(19283765, 7, 0),
(84637583, 8, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `marca`
--

CREATE TABLE `marca` (
  `codigo` bigint(20) NOT NULL,
  `logotipo` varchar(500) NOT NULL,
  `nombre` varchar(500) CHARACTER SET latin1 COLLATE latin1_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `marca`
--

INSERT INTO `marca` (`codigo`, `logotipo`, `nombre`) VALUES
(8, 'dhjkjvlbj.png', 'dhjkjvlbj'),
(16, 'Loui.jpg', 'Loui'),
(17, 'Diamond Supply CO.jpg', 'Diamond Supply CO');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `negocio`
--

CREATE TABLE `negocio` (
  `cif` bigint(8) NOT NULL,
  `nombre` varchar(50) CHARACTER SET latin1 COLLATE latin1_spanish_ci NOT NULL,
  `usuario` varchar(50) CHARACTER SET latin1 COLLATE latin1_spanish_ci NOT NULL,
  `contraseña` varchar(20) CHARACTER SET latin1 COLLATE latin1_spanish_ci NOT NULL,
  `telefono` int(12) NOT NULL,
  `tipo` varchar(500) CHARACTER SET latin1 COLLATE latin1_spanish_ci NOT NULL,
  `foto` varchar(1000) CHARACTER SET latin1 COLLATE latin1_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `negocio`
--

INSERT INTO `negocio` (`cif`, `nombre`, `usuario`, `contraseña`, `telefono`, `tipo`, `foto`) VALUES
(11925764, 'Real Skateboards', 'real', 'real', 3472852, 'Escuela', 'Real Skateboards.jpg'),
(30456434, 'Primitive', 'primitive', 'primitive', 34662, 'Tienda de deporte', 'Primitive.png'),
(49895673, 'LRG', 'lrg', 'lrg', 1274562, 'Tienda de ropa', 'LRG.jpg'),
(91827364, 'Almost', 'almost', 'almost', 2587625, 'Escuela', 'Almost.png'),
(92384754, 'Vans', 'vans', 'vans', 195937, 'Escuela', 'Vans.png');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `deportista`
--
ALTER TABLE `deportista`
  ADD PRIMARY KEY (`dni`);

--
-- Indices de la tabla `evento`
--
ALTER TABLE `evento`
  ADD PRIMARY KEY (`codigo`),
  ADD KEY `evento_ibfk_1` (`cif`);

--
-- Indices de la tabla `inscribe`
--
ALTER TABLE `inscribe`
  ADD PRIMARY KEY (`dni`,`evento`),
  ADD KEY `inscribe_ibfk_2` (`evento`);

--
-- Indices de la tabla `marca`
--
ALTER TABLE `marca`
  ADD PRIMARY KEY (`codigo`);

--
-- Indices de la tabla `negocio`
--
ALTER TABLE `negocio`
  ADD PRIMARY KEY (`cif`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `evento`
--
ALTER TABLE `evento`
  MODIFY `codigo` bigint(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de la tabla `marca`
--
ALTER TABLE `marca`
  MODIFY `codigo` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `evento`
--
ALTER TABLE `evento`
  ADD CONSTRAINT `evento_ibfk_1` FOREIGN KEY (`cif`) REFERENCES `negocio` (`cif`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `inscribe`
--
ALTER TABLE `inscribe`
  ADD CONSTRAINT `inscribe_ibfk_1` FOREIGN KEY (`dni`) REFERENCES `deportista` (`dni`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `inscribe_ibfk_2` FOREIGN KEY (`evento`) REFERENCES `evento` (`codigo`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
