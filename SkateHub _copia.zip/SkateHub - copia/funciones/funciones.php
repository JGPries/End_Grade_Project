<?php

    function menu($parametro1="../../",$parametro2="../",$parametro3="../../assets/"){

        if(isset($_SESSION['cif'])){

            echo"
                <nav class='navbar sticky-top navbar-expand-lg navbar-dark bg-dark'>
                    <div class='container-fluid'>
                        <a class='navbar-brand' href='$parametro1"."index.php'>
                            <img src='$parametro3"."skatelogo3.png' alt='' width='78' height='60'>
                        </a>
                        <button class='navbar-toggler' type='button' data-bs-toggle='collapse' data-bs-target='#navbarSupportedContent' aria-controls='navbarSupportedContent' aria-expanded='false' aria-label='Toggle navigation'>
                            <span class='navbar-toggler-icon'></span>
                        </button>
                        <div class='collapse navbar-collapse' id='navbarSupportedContent'>
                            <ul class='navbar-nav me-auto mb-2 mb-lg-0'>
                                <li class='nav-item'>
                                    <a class='nav-link active' aria-current='page' href='$parametro1"."index.php'>PERFIL</a>
                                </li>
                                <li class='nav-item'>
                                    <a class='nav-link active' aria-current='page' href='$parametro2"."evento/vista_evento.php'>EVENTOS</a>
                                </li>
                                <li class='nav-item'>
                                    <a class='nav-link active' aria-current='page' href='$parametro2"."deportista/vista_deportista.php'>DEPORTISTAS</a>
                                </li>
                                <li class='nav-item'>
                                    <a class='nav-link active' aria-current='page' href='$parametro2"."negocio/vista_negocio.php'>NEGOCIOS</a>
                                </li>
                                <li class='nav-item'>
                                    <a class='nav-link active' aria-current='page' href='$parametro2"."marca/vista_marcas.php'>MARCAS</a>
                                </li>
                                <li class='nav-item'>
                                    <a class='nav-link active' aria-current='page' href='$parametro2"."../controladores/sesiones/control_cerrar_sesion.php'>DESCONECTAR</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </nav>
            ";

        }elseif(isset($_SESSION['dni'])){

            echo"
                <nav class='navbar sticky-top navbar-expand-lg navbar-dark bg-dark'>
                    <div class='container-fluid'>
                        <a class='navbar-brand' href='$parametro1"."index.php'>
                            <img src='$parametro3"."skatelogo3.png' alt='' width='78' height='60'>
                        </a>
                        <button class='navbar-toggler' type='button' data-bs-toggle='collapse' data-bs-target='#navbarSupportedContent' aria-controls='navbarSupportedContent' aria-expanded='false' aria-label='Toggle navigation'>
                            <span class='navbar-toggler-icon'></span>
                        </button>
                        <div class='collapse navbar-collapse' id='navbarSupportedContent'>
                            <ul class='navbar-nav me-auto mb-2 mb-lg-0'>
                                <li class='nav-item'>
                                    <a class='nav-link active' aria-current='page' href='$parametro1"."index.php'>PERFIL</a>
                                </li>
                                <li class='nav-item'>
                                    <a class='nav-link active' aria-current='page' href='$parametro2"."evento/vista_evento.php'>EVENTOS</a>
                                </li>
                                <li class='nav-item'>
                                    <a class='nav-link active' aria-current='page' href='$parametro2"."deportista/vista_deportista.php'>DEPORTISTAS</a>
                                </li>
                                <li class='nav-item'>
                                    <a class='nav-link active' aria-current='page' href='$parametro2"."negocio/vista_negocio.php'>NEGOCIOS</a>
                                </li>
                                <li class='nav-item'>
                                    <a class='nav-link active' aria-current='page' href='$parametro2"."marca/vista_marcas.php'>MARCAS</a>
                                </li>
                                <li class='nav-item'>
                                    <a class='nav-link active' aria-current='page' href='$parametro2"."../controladores/sesiones/control_cerrar_sesion.php'>DESCONECTAR</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </nav>
            ";

        }else{

            echo"
                <nav class='navbar sticky-top navbar-expand-lg navbar-dark bg-dark'>
                    <div class='container-fluid'>
                        <a class='navbar-brand' href='$parametro1"."index.php'>
                            <img src='$parametro3"."skatelogo3.png' alt='' width='60' height='54'>
                        </a>
                        <button class='navbar-toggler' type='button' data-bs-toggle='collapse' data-bs-target='#navbarSupportedContent' aria-controls='navbarSupportedContent' aria-expanded='false' aria-label='Toggle navigation'>
                            <span class='navbar-toggler-icon'></span>
                        </button>
                        <div class='collapse navbar-collapse' id='navbarSupportedContent'>
                            <ul class='navbar-nav me-auto mb-2 mb-lg-0'>
                                <li class='nav-item'>
                                    <a class='nav-link active' aria-current='page' href='$parametro1"."index.php'>INICIO</a>
                                </li>
                                <li class='nav-item'>
                                    <a class='nav-link active' aria-current='page' href='$parametro2"."evento/vista_evento.php'>EVENTOS</a>
                                </li>
                                <li class='nav-item'>
                                    <a class='nav-link active' aria-current='page' href='$parametro2"."deportista/vista_deportista.php'>DEPORTISTAS</a>
                                </li>
                                <li class='nav-item'>
                                    <a class='nav-link active' aria-current='page' href='$parametro2"."negocio/vista_negocio.php'>NEGOCIOS</a>
                                </li>
                                <li class='nav-item'>
                                    <a class='nav-link active' aria-current='page' href='$parametro2"."marca/vista_marcas.php'>MARCAS</a>
                                </li>
                                <li class='nav-item'>
                                    <a class='nav-link active' aria-current='page' href='$parametro2"."acceder/acceder.php'>INICIAR SESIÓN</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </nav>
            ";

        }

    }

    function footer($parametro1="../",$parametro2=""){

        echo 
            "
                <footer class='site-footer'>
                    <div class='container'>
                        <div class='row'>
                            <div class='col-sm-12 col-md-6'>
                                <h6>Contacto</h6>
                                <p>Avda. Doctor Olóriz, 6. Granada, 18012.</p>
                                <p>958 27 80 60</p>
                                <p>info@escuelaartegranada.com</p>
                                <p>Lunes a viernes: 8.30h a 22.00h</p>
                            </div>

                            <div class='col-xs-6 col-md-3'>
                                <h6>Links</h6>
                                <ul class='footer-links'>
                                <li><a href='$parametro2"."legalcontent/aviso_legal.php'>Aviso legal</a></li>
                                <li><a href='$parametro2"."legalcontent/politica_cookies.php'>Política de cookies</a></li>
                                </ul>
                            </div>

                            <iframe src='https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d668.2089345153429!2d-3.608338339822763!3d37.1870385119236!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xd71fcef3c4fe4ff%3A0xb362c7165dc2ded2!2sEscuela%20Arte%20Granada!5e0!3m2!1sen!2ses!4v1645381456278!5m2!1sen!2ses' width='400' height='300' style='border:0;' allowfullscreen='' loading='lazy'></iframe>

                        </div>
                        <hr>

                    </div>
                    <div class='container'>
                        <div class='row'>
                            <div class='col-md-8 col-sm-6 col-xs-12'>
                                <p class='copyright-text'>Copyright &copy; 2022 All Rights Reserved by 
                                    <a href='https://www.escuelaartegranada.com/'>ESCUELAARTEGRANADA</a>.
                                </p>
                            </div>

                            <div class='col-md-4 col-sm-6 col-xs-12'>
                                <ul class='social-icons'>
                                    <li><a class='facebook' href='https://www.escuelaartegranada.com/'><i class='fa fa-facebook'></i></a></li>
                                    <li><a class='twitter' href='https://www.escuelaartegranada.com/'><i class='fa fa-twitter'></i></a></li>
                                    <li><a class='dribbble' href='https://www.escuelaartegranada.com/'><i class='fa fa-dribbble'></i></a></li>
                                    <li><a class='linkedin' href='https://www.escuelaartegranada.com/'><i class='fa fa-linkedin'></i></a></li>   
                                </ul>
                            </div>
                        </div>
                    </div>
                </footer>
            ";

    }

    function convertir_fecha($fecha){
        return date("d/m/Y",strtotime($fecha));
    }

?>