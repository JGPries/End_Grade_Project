<?php

	require_once "modelo/evento.php";
	
	$verificaciones=new modelo_evento();

    $eventosN=$verificaciones->eventos_neg($_SESSION['cif']);		
	
	require_once "index.php";

?> 



