<?php

	require_once "../../modelo/evento.php";
	
	$verificaciones=new modelo_evento();

    $datos=$verificaciones->get_eventos();		
	
	
	require_once "../../vistas/evento/vista_evento.php";

?>