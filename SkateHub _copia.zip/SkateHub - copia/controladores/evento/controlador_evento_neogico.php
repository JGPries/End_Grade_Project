<?php

    require_once "../../modelo/negocio.php";

    $verificaciones = new modelo_negocios();

    $selectNegocio = $verificaciones-> buscar_cif($_SESSION['cif']);

    require_once "../../vistas/evento/insertar_evento.php";

?>