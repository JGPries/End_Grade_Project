<?php

    require_once "../../modelo/evento.php";

    $verificaciones = new modelo_evento();

    if(isset($_POST["borrarevento"])){

        $eventoN=$verificaciones->borrar_evento($_POST["codigo"],$_POST["cif"],$_POST["nombre"],$_POST["foto"],$_POST["descripción"],$_POST["fecha"]);

    }

    header("location:../../index.php");

?>