<?php

    require_once "../../modelo/evento.php";

    $verificaciones=new modelo_evento();

    $negocios=$verificaciones->selectNegocio();

    require_once "../../vistas/evento/insertar_evento.php";

?>