<?php

    require_once "../../modelo/evento.php";

    $verificaciones = new modelo_evento();

    if(isset($_POST['vereventoo'])){

        $ver=$verificaciones->buscar_cod($_POST['codigo']);

    }

    require_once "../../vistas/evento/vermas_eventos.php";

?>