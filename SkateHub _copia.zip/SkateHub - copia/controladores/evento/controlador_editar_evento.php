<?php

    require_once "../../modelo/evento.php";

    $verificaciones = new modelo_evento();

    if(isset($_POST["codmod"])){

        $editacion=$verificaciones->buscar_cod($_POST['codigoedit']);

    }

    require_once "../../modelo/inscripciones.php";

    $inscrip = new modelo_inscripcion();

    if(isset($_POST["codmod"])){

        $lists = $inscrip->listitas($_POST['codigoedit']);

    }

    require_once "../../vistas/evento/editar_evento.php";

?>