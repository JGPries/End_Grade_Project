<?php

	require_once "modelo/evento.php";
	
	$verificaciones=new modelo_evento();

    $datos=$verificaciones->ult_eventos();		
	
	require_once "index.php";

?>