<?php

	require_once "modelo/evento.php";
	
	$verificaciones=new modelo_evento();

    $datos2=$verificaciones->ant_eventos();		
	
	
	require_once "index.php";

?>