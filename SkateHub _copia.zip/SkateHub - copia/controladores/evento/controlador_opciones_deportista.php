<?php

    require_once "../../modelo/evento.php";

    $verificaciones=new modelo_evento();

    $deportistas=$verificaciones->selectDeportista();

    require_once "../../vistas/evento/vermas_eventos.php";

?>