<?php

    require_once "../../modelo/evento.php";

    $verificaciones=new modelo_evento();


    if(isset($_POST["enviar"])){

        $verificaciones->añadir_eventos($_POST["cif"],$_POST["nombre"],$_FILES["imagen"],$_POST["descripción"],$_POST["fecha"]);		
    
    }
 
    header("location:../../vistas/evento/vista_evento.php");

?>
