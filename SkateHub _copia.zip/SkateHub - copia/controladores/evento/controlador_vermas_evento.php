<?php

    require_once "../../modelo/evento.php";

    $verificaciones = new modelo_evento();

    if(isset($_POST['vermas'])){

        $ver=$verificaciones->buscar_cod($_POST['codigo']);

    }

    // Para mostrar las listas

    require_once "../../modelo/inscripciones.php";
	
	$inscritos=new modelo_inscripcion();

    if(isset($_POST['vermas'])){

        $listas=$inscritos->get_inscripciones($_POST['codigo']);

    }

    require_once "../../vistas/evento/vermas_eventos.php";

?>