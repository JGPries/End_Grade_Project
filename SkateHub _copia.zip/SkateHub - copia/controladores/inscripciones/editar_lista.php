<?php

    require_once "../../modelo/inscripciones.php";

    $verificaciones = new modelo_inscripcion();

    if(isset($_POST["inscmod"])){

        $editacion=$verificaciones->buscar_inscripcion($_POST['inscedit'],$_POST['evenedit']);

    }

    require_once "../../vistas/inscripciones/editar_inscripcion.php";

?>