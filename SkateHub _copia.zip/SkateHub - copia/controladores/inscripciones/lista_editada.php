<?php

    require_once "../../modelo/inscripciones.php";

    $verificaciones = new modelo_inscripcion();

    if(isset($_POST["editlist"])){

        $editacion=$verificaciones->editar_listas($_POST["dni"],$_POST["evento"],$_POST["puntuacion"]);

    }

    header("location:../../index.php");

?>