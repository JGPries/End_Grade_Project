<?php

	require_once "../../modelo/inscripciones.php";
	
	$verificaciones=new modelo_inscripcion();

    $listas=$verificaciones->get_inscripciones();		
	
	require_once "../../vistas/evento/vermas_eventos.php";

?>