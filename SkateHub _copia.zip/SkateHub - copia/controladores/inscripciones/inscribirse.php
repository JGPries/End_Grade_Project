<?php

    require_once "../../modelo/inscripciones.php";

    $verificaciones = new modelo_inscripcion();

    if(isset($_POST['insc'])){

        $verificaciones->nueva_ins($_POST['dni'],$_POST['evento']);

    }
    
	require_once "../../vistas/evento/vista_evento.php";
    
?>