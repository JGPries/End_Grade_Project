<?php

    require_once "../../modelo/negocio.php";

    $verificaciones = new modelo_negocios();

    if(isset($_POST["borrarneg"])){

        $perfilN=$verificaciones->borrar_negocio($_POST["cif"],$_POST["nombre"],$_POST["usuario"],$_POST["contraseña"],$_POST["telefono"],$_POST["tipo"],$_POST["foto"]);

    }

    header("location:../../vistas/acceder/acceder.php");

?>