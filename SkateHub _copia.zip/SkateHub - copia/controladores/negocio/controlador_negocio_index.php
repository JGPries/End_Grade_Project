<?php

	require_once "modelo/negocio.php";
	
	$verificaciones=new modelo_negocios();

	$perfilN=$verificaciones->perfil_negocio($_SESSION['cif']);	
	    	
	require_once "index.php";

?>