<?php

    require_once "../../modelo/negocio.php";

    $verificaciones=new modelo_negocios();


    if(isset($_POST["enviar"])){

        $verificaciones->añadir_negocios($_POST["cif"],$_POST["nombre"],$_POST["usuario"],$_POST["contraseña"],$_POST["telefono"],$_POST["tipo"],$_FILES["imagen"]);		
    
    }
 
    header("location:../../vistas/acceder/acceder.php");

?>