<?php

    require_once "../../modelo/negocio.php";

    $verificaciones = new modelo_negocios();

    if(isset($_POST['vermas'])){

        $ver=$verificaciones->buscar_cif($_POST['cif']);

        $event=$verificaciones->eventneg($_POST['cif']);

    }

    require_once "../../vistas/negocio/vermas_negocio.php";

?>