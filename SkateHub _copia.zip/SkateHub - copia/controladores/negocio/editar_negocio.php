<?php

    require_once "../../modelo/negocio.php";

    $verificaciones = new modelo_negocios();

    if(isset($_POST["cifmod"])){

        $editacion=$verificaciones->buscar_cif($_POST['cifselect']);

    }

    require_once "../../vistas/negocio/editar_negocio.php";

?>