<?php

	require_once "../../modelo/negocio.php";
	
	$verificaciones=new modelo_negocios();

    $datos=$verificaciones->get_negocio();		
	
	
	require_once "../../vistas/negocio/vista_negocio.php";

?>