<?php

    session_start();

    require_once "../../modelo/sesiones.php";

    $verificaciones=new modelo_sesiones();

    if(isset($_POST['enviarDepor'])){

        if(isset($_POST['bloquear'])){

            $account=$verificaciones->validar_cuenta_d($_POST['dni'],$_POST['contraseña'],$_POST['bloquear']);

            header("location:../../index.php");

        }else{

            $account=$verificaciones->validar_cuenta_d($_POST['dni'],$_POST['contraseña'],$_POST['bloquear']);

            header("location:../../index.php");

        }

        if($verificaciones->validar_cuenta_d($_POST['dni'],$_POST['contraseña'],$_POST['bloquear'])===0){

            echo"<meta http-equiv='refresh' content='0;url=../../vistas/acceder/acceder.php'>";

        }else{

            header("location:../../index.php");

        }

    }

?>