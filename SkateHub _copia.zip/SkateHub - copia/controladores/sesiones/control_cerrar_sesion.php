<?php

    session_start();
    $_SESSION=array();
    session_destroy();

    setcookie("sesh","",-1,"/");

    header("location:../../index.php");

?>