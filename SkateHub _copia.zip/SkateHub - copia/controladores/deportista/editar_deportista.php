<?php

    require_once "../../modelo/deportista.php";

    $verificaciones = new modelo_deportista();

    if(isset($_POST["dnimod"])){

        $editacion=$verificaciones->buscar_dni($_POST['dniselect']);

    }

    require_once "../../vistas/deportista/editar_deportista.php";

?>