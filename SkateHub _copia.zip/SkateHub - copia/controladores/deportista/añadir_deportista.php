<?php

    require_once "../../modelo/deportista.php";

    $verificaciones=new modelo_deportista();


    if(isset($_POST["enviar"])){

        $verificaciones->añadir_deportistas($_POST["dni"],$_POST["nombre"],$_POST["apellido"],$_POST["usuario"],$_POST["contraseña"],$_POST["telefono"],$_POST["fecha"],$_FILES["imagen"]);		
    
    }
 
    header("location:../../vistas/acceder/acceder.php");

?>