<?php

	require_once "../../modelo/deportista.php";
	
	$verificaciones=new modelo_deportista();

    $datos=$verificaciones->get_deportista();		
	
	require_once "../../vistas/deportista/vista_deportista.php";

?>