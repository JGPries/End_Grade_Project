<?php

	require_once "modelo/deportista.php";
	
	$verificaciones=new modelo_deportista();

    $perfilD=$verificaciones->perfil_deportista($_SESSION['dni']);		
	
	require_once "index.php";

?>