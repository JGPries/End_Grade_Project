<?php

    require_once "../../modelo/deportista.php";

    $verificaciones = new modelo_deportista();

    if(isset($_POST["borrardeport"])){

        $perfilD=$verificaciones->borrar_deportista($_POST["dni"],$_POST["nombre"],$_POST["apellido"],$_POST["usuario"],$_POST["contraseña"],$_POST["telefono"],$_POST["fecha"],$_POST["foto"]);

    }

    header("location:../../vistas/acceder/acceder.php");

?>