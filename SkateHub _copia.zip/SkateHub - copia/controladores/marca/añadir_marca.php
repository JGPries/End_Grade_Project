<?php

    require_once "../../modelo/marca.php";

    $verificaciones=new modelo_marcas();


    if(isset($_POST["enviar"])){

        $verificaciones->añadir_marcas($_FILES["foto"],$_POST["nombre"]);		
    
    }
 
    header("location:../../vistas/marca/vista_marcas.php");

?>