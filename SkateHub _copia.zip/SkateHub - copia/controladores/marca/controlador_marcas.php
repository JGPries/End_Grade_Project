<?php

	require_once "../../modelo/marca.php";
	
	$verificaciones=new modelo_marcas();

    $datos=$verificaciones->get_marcas();		
	
	require_once "../../vistas/marca/vista_marca.php";

?>