<?php

    require_once "../../modelo/marca.php";

    $verificaciones = new modelo_marcas();

    if(isset($_POST["borrarmarca"])){

        $dato=$verificaciones->borrar_marca($_POST["codigo"],$_POST["logotipo"],$_POST["nombre"]);

    }

    header("location:../../vistas/marca/vista_marca.php");

?>