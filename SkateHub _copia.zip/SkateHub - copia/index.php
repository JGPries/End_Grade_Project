<?php
    session_start();
	if(isset($_COOKIE['sesh'])){
        session_decode($_COOKIE['sesh']);
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>SKATE HUB</title>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
	<link href="css/stylo.css" rel="stylesheet">
	<link href="assets/favicon2.png" rel="icon" type="image/png">
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Kufam&display=swap" rel="stylesheet">
</head>
<body>

	<header>

        <?php

			require_once("funciones/funciones.php");

			$parametro1="";
			$parametro2="vistas/";
			$parametro3="assets/";
			
            echo"
                <div>
                    <div class='parallax'>
                    
                        <div class='container1'>
                        
                            <div class='container2'>
                                <div id='opening'>
                                    <div>
                                        <h1 id='titulo1'> SKATE HUB </h1>
                                        <img src='$parametro3"."skatelogo3.png'>
                                    </div>
                                </div>
                            </div>

                        </div>
                    
                    </div>

                </div>
                    
            ";

		?>

	</header>

	<main id="indexmain">

        <?php

            menu($parametro1,$parametro2,$parametro3);

            if(isset($_SESSION['cif'])){

                // Perfil negocio
                require_once("controladores/negocio/controlador_negocio_index.php");

                if(isset($perfilN)){

                    echo"

                        <div class='container my-5' align='center'>
                            <form id='form_insertar' action='controladores/negocio/negocio_editado.php' method='POST' enctype='multipart/form-data'>

                                <div class='mb-3'>
                                    <img src='assets/imagenes/$perfilN[foto]' class='card-img-top' class='img-fluid'>
                                </div>
                                <br>
                                <div class='mb-3'>
                                    <label for='nombre' class='form-label'></label>
                                    <input type='text' class='form-control' placeholder='Nombre' name='nombre' id='nombre' value='$perfilN[nombre]'>
                                </div>
                                <br>
                                <div class='mb-3'>
                                    <label for='usuario' class='form-label'>Nombre de usuario</label>
                                    <input type='text' class='form-control' placeholder='Nombre de usuario' name='usuario' id='usuario' value='$perfilN[usuario]'>
                                </div>
                                <br>
                                <div class='mb-3'>
                                    <label for='contraseña' class='form-label'>Contraseña</label>
                                    <input type='text' class='form-control' placeholder='Contraseña' id='contraseña' name='contraseña' value='$perfilN[contraseña]'>
                                </div>
                                <br>
                                <div class='mb-3'>
                                    <label for='telefono' class='form-label'>Número de contacto</label>
                                    <input type='text' class='form-control' placeholder='Número de contacto' id='telefono' name='telefono' value='$perfilN[telefono]'>
                                </div>
                                <br>
                                <input type='submit' class='boton1' name='enviarn' value='Actualizar perfil'>
                                <input type='hidden' name='cif' value='$perfilN[cif]'>
                                <input type='hidden' name='foto' value='$perfilN[foto]'>
                            </form>
                        </div>

                        <div class='container my-5' align='center'>

                            <form action='controladores/negocio/controlador_borrar_negocio.php' method='POST' >
                                <input type='submit' value='Borrar cuenta' name='borrarneg' class='btn btn-danger'>
                                <input type='hidden' name='cif' value='$perfilN[cif]'>
                                <input type='hidden' name='nombre' value='$perfilN[nombre]'>
                                <input type='hidden' name='usuario' value='$perfilN[usuario]'>
                                <input type='hidden' name='contraseña' value='$perfilN[contraseña]'>
                                <input type='hidden' name='telefono' value='$perfilN[telefono]'>
                                <input type='hidden' name='tipo' value='$perfilN[tipo]'>
                                <input type='hidden' name='foto' value='$perfilN[foto]'>
                            </form>

                        </div>

                    ";

                    

                }

                // Para mostrar los eventos de la empresa conectada
                require_once("controladores/evento/controlador_negocio_index.php");
                    
                if(isset($eventosN)){

                    echo"<div class='diveventos2'>
                            <div class='row'>       
                    ";

                    foreach($eventosN as $eventoN){

                        echo"

                            <div class='col-6'>
                                    
                                <div class='card my-5' >
                                    
                                    <img src='assets/imagenes/$eventoN[foto]' class='img-fluid' >
                                    
                                    <div class='card-body'>
                                        <h4>$eventoN[nombre]</h4>
                                        <p>".convertir_fecha($eventoN['fecha'])."</p>";

                                        $today=date('Y-m-d');
                                        if($eventoN['fecha']<$today){
                                            echo"<div>
                                                    <form action='controladores/evento/controlador_editar_evento.php' method='POST' >
                                                        <input type='submit' value='editar' name='codmod' class='btn btn-success'>
                                                        <input type='hidden' value='$eventoN[codigo]' name='codigoedit'>
                                                    </form>
                                                </div>";
                                        }
                                        
                                    echo"   <br><div>
                                                <form action='controladores/evento/controlador_borrar_evento.php' method='POST' >
                                                    <input type='submit' value='Borrar evento' name='borrarevento' class='btn btn-danger'>
                                                    <input type='hidden' name='codigo' value='$eventoN[codigo]'>
                                                    <input type='hidden' name='cif' value='$eventoN[cif]'>
                                                    <input type='hidden' name='nombre' value='$eventoN[nombre]'>
                                                    <input type='hidden' name='foto' value='$eventoN[foto]'>
                                                    <input type='hidden' name='descripción' value='$eventoN[descripción]'>
                                                    <input type='hidden' name='fecha' value='$eventoN[fecha]'>
                                                </form>
                                            </div>
                                    
                                    </div>
                                </div>
                                
                            </div>
                        ";

                    }
                    echo"</div></div>";

                }else{

                    echo"
                        <div>
                            <h2>No hay eventos actualmente</h2>
                        </div>";

                }


            }elseif(isset($_SESSION['dni'])){

                // Perfil deportista
                require_once("controladores/deportista/controlador_deportista_index.php");

                if(isset($perfilD)){

                    echo"

                        <div class='container my-5' align='center'>
                            <img src='assets/imagenes/$perfilD[foto]' class='img-fluid'>
                        </div>

                        <div class='container my-5' align='center'>
                            <form id='form_insertar' action='controladores/deportista/deportista_editado.php' method='POST' enctype='multipart/form-data'>
                                
                                <div class='mb-3'>
                                    <label for='nombre' class='form-label'></label>
                                    <input type='text' class='form-control' placeholder='Nombre' name='nombre' id='nombre' value='$perfilD[nombre]'>
                                </div>
                                <br>
                                <div class='mb-3'>
                                    <label for='apellido' class='form-label'></label>
                                    <input type='text' class='form-control' placeholder='Apellido' name='apellido' id='apellido' value='$perfilD[apellido]'>
                                </div>
                                <br>
                                <div class='mb-3'>
                                    <label for='usuario' class='form-label'>Nombre de usuario</label>
                                    <input type='text' class='form-control' placeholder='Nombre de usuario' name='usuario' id='usuario' value='$perfilD[usuario]'>
                                </div>
                                <br>
                                <div class='mb-3'>
                                    <label for='contraseña' class='form-label'>Contraseña</label>
                                    <input type='text' class='form-control' placeholder='Contraseña' id='contraseña' name='contraseña' value='$perfilD[contraseña]'>
                                </div>
                                <br>
                                <div class='mb-3'>
                                    <label for='telefono' class='form-label'>Número de contacto</label>
                                    <input type='text' class='form-control' placeholder='Número de contacto' id='telefono' name='telefono' value='$perfilD[telefono]'>
                                </div>
                                <br>
                                <input type='submit' class='boton1' name='enviard' value='Actualizar perfil'>
                                <input type='hidden' name='dni' value='$perfilD[dni]'>
                                <input type='hidden' name='fecha' value='$perfilD[fecha]'>
                                <input type='hidden' name='foto' value='$perfilD[foto]'>
                            </form>
                        </div>

                        <div class='container my-5' align='center'>

                            <form action='controladores/deportista/controlador_borrar_deportista.php' method='POST' >
                                <input type='submit' value='Borrar cuenta' name='borrardeport' class='btn btn-danger'>
                                <input type='hidden' name='dni' value='$perfilD[dni]'>
                                <input type='hidden' name='nombre' value='$perfilD[nombre]'>
                                <input type='hidden' name='apellido' value='$perfilD[apellido]'>
                                <input type='hidden' name='usuario' value='$perfilD[usuario]'>
                                <input type='hidden' name='contraseña' value='$perfilD[contraseña]'>
                                <input type='hidden' name='telefono' value='$perfilD[telefono]'>
                                <input type='hidden' name='fecha' value='$perfilD[fecha]'>
                                <input type='hidden' name='foto' value='$perfilD[foto]'>
                            </form>

                        </div>

                    ";
                }

            }else{

                // Proximos eventos
                echo"
                    <div class='my-5'>
                        <h1 id='titulo1'>PRÓXIMOS EVENTOS</h1>
                    </div>
                ";

                require_once("controladores/evento/controlador_evento_index.php");

                if(isset($datos)){

                    echo"<div class='diveventos'>
                            <div class='row'>       
                    ";

                    foreach($datos as $dato){

                        echo"

                            <div class='col-6'>
                                
                                <div class='card my-5' >
                                    
                                    <img src='assets/imagenes/$dato[foto]' class='card-img-top'>
                                    
                                    <div class='card-body'>
                                        <h4>$dato[nombre]</h4>
                                        <p>".convertir_fecha($dato['fecha'])."</p>
                                        <p>
                                            <form action='controladores/evento/controlador_vermas_index.php' method='POST'>
                                                <input type='submit' value='ver más' name='vereventoo' class='btn btn-danger'>
                                                <input type='hidden' value='$dato[codigo]' name='codigo'>
                                            </form>
                                        </p>
                                    </div>
                                </div>
                                
                            </div>
                        ";

                    }
                    echo"</div></div>";

                }else{

                    echo"
                        <div>
                            <h2>No hay eventos actualmente</h2>
                        </div>";

                }

                // Eventos antiguos
                require_once("controladores/evento/controlador_evento_index2.php");

                echo"
                    <div class='my-5'>
                        <h1 id='titulo1'>EVENTOS PASADOS</h1>
                    </div>
                ";

                if(isset($datos2)){

                    echo"<div class='diveventos'>
                            <div class='row'>       
                    ";

                    foreach($datos2 as $dato2){

                        echo"

                            <div class='col-6'>
                                    
                                <div class='card my-5' >
                                    
                                    <img src='assets/imagenes/$dato2[foto]' class='card-img-top'>
                                    
                                    <div class='card-body'>
                                        <h4>$dato2[nombre]</h4>
                                        <p>".convertir_fecha($dato2['fecha'])."</p>
                                        <p>
                                            <form action='controladores/evento/controlador_vermas_index.php' method='POST'>
                                                <input type='submit' value='ver más' name='vereventoo' class='btn btn-danger'>
                                                <input type='hidden' value='$dato2[codigo]' name='codigo'>
                                            </form>
                                        </p>
                                    </div>
                                </div>
                                
                            </div>
                        ";

                    }
                    echo"</div></div>";

                }else{

                    echo"
                        <div>
                            <h2>No hay eventos actualmente</h2>
                        </div>";

                }

                // CARROUSEL MARCAS

                echo"
                    <div class=' titulcarr my-5'>
                        <h1 id='titulo1'>MARCAS CON LAS QUE COLABORAMOS</h1>
                    </div>
                ";

                echo"

                    <div class='containerCarr'>
                        <div class='row w-100 '>
                            <div class='col w-100 d-flex justify-content-center'>

                                <div id='carouselExampleIndicators' class='carousel slide' data-bs-ride='carousel'>
                                <div class='carousel-indicators'>
                                    <button type='button' data-bs-target='#carouselExampleIndicators' data-bs-slide-to='0' class='active' aria-current='true' aria-label='Slide 1'></button>
                                    <button type='button' data-bs-target='#carouselExampleIndicators' data-bs-slide-to='1' aria-label='Slide 2'></button>
                                    <button type='button' data-bs-target='#carouselExampleIndicators' data-bs-slide-to='2' aria-label='Slide 3'></button>
                                </div>

                                <div class='carousel-inner text-center'>";
                                require_once "controladores/marca/controlador_carrousel.php";
                                if(isset($marc)){

                                    $activo=0;
                                    $contador=1;
                                    foreach($marc as $marcas){

                                        if($activo==0){

                                            echo"<div class='carousel-item  active'>";
                                            
                                        }else{
                                            echo"<div class='carousel-item '>";
                                        }
                                        
                                        echo"
                                                <img src='assets/imagenes/$marcas[logotipo]' alt='serie $contador'>
                                                <h3>$marcas[nombre]</h3>
                                                <p class='placeholder-wave'>
                                                    <span class='placeholder col-12'></span>
                                                </p>
                                            </div>
                                        ";
                                        $activo++;
                                        $contador++;
                                    }

                                }
                                
                            echo"
                                </div>
                                <button class='carousel-control-prev' type='button' data-bs-target='#carouselExampleIndicators' data-bs-slide='prev'>
                                    <span class='carousel-control-prev-icon' aria-hidden='true'></span>
                                    <span class='visually-hidden'>Previous</span>
                                </button>
                                <button class='carousel-control-next' type='button' data-bs-target='#carouselExampleIndicators' data-bs-slide='next'>
                                    <span class='carousel-control-next-icon' aria-hidden='true'></span>
                                    <span class='visually-hidden'>Next</span>
                                </button>
                            </div>


                            </div>
                        </div>
                    </div>

                
                ";

            }

        ?>

	</main>

	<?php

        footer($parametro1,$parametro2,$parametro3);

    ?>

</body>
</html>