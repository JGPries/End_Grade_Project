<?php

	require_once("bd.php");

	class modelo_inscripcion{
		private $bd;
		private $inscripciones;

		public function __construct(){
		
			$this->bd=conexiones::conectar();
		}

		public function get_inscripciones($codigo){

			$datos_insc=$this->bd->query("SELECT d.nombre nom_dep,d.apellido apell_dep, i.puntuacion puntu 
											from inscribe i, deportista d, evento e 
											where i.evento = e.codigo and i.dni=d.dni and e.codigo='$codigo'");

			while($filas=$datos_insc->fetch_assoc()){

				$this->inscripciones[]=$filas;

			}

			return $this->inscripciones;

		}

		public function nueva_ins($dni, $evento){

			$insc= $this->bd->prepare("INSERT into inscribe values (?,?,?) ");
            $puntuacion=0;
            $insc->bind_param("iii", $dni,$evento,$puntuacion);
            $insc->execute();

            $insc->close();

        }

		public function editar_listas($dni,$evento,$puntuacion){

			$editar_lista=$this->bd->prepare("UPDATE inscribe set puntuacion=? where dni=$dni and evento=$evento ");

			$editar_lista->bind_param("iii",$dni,$evento,$puntuacion);
			$editar_lista->execute();
			$editar_lista->close();

		}

		public function buscar_inscripcion($dni,$codigo){

			$busc=$this->bd->prepare("SELECT d.dni dnii,d.nombre nom_dep,d.apellido apell_dep,d.foto perfil, i.puntuacion puntu, e.codigo codigoo 
										from inscribe i, deportista d, evento e 
										where i.evento = e.codigo and i.dni=d.dni and i.dni=$dni and e.codigo=$codigo");
			$busc->bind_param("ii",$dni,$evento);
			$busc->bind_result($dnii,$nom_dep,$apell_dep,$perfil,$puntu,$codigoo);
			$busc->execute();
			$busc->fetch();

				$this->inscripciones["dnii"]=$dnii;
				$this->inscripciones["nom_dep"]=$nom_dep;
				$this->inscripciones["apell_dep"]=$apell_dep;
				$this->inscripciones["perfil"]=$perfil;
				$this->inscripciones["puntu"]=$puntu;
				$this->inscripciones["codigoo"]=$codigoo;

				$busc->close();

				return $this->inscripciones;

		}

		public function listitas($codigo){

			$datos_insc=$this->bd->query("SELECT d.dni dnii, d.nombre nom_dep,d.apellido apell_dep, e.codigo codigoo, i.puntuacion puntu 
											from inscribe i, deportista d, evento e 
											where i.evento = e.codigo and i.dni=d.dni and e.codigo='$codigo'");

			while($filas=$datos_insc->fetch_assoc()){

				$this->inscripciones[]=$filas;

			}

			return $this->inscripciones;

		}


	}

?>