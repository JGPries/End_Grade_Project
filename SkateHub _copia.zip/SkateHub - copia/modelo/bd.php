<?php

    class conexiones{

        public static function conectar(){

            $conexion = new mysqli("localhost","root","","skatehub");
            $conexion->set_charset("utf8");

            return $conexion;

        }

    }
    
?>