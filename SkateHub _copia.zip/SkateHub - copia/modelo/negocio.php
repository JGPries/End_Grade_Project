<?php

	require_once("bd.php");

	class modelo_negocios{

		private $bd;
		private $negocio;
	
		public function __construct(){
		
			$this->bd=conexiones::conectar();
		}

		public function get_negocio(){
			
			$consulta=$this->bd->query("SELECT * from negocio ");

			while($filas=$consulta->fetch_assoc()){

				$this->negocio[]=$filas;

			}

			$consulta->close();

			return $this->negocio;
		}

		public function perfil_negocio($cif){

			$cif_perfil = $this->bd->prepare("SELECT * from negocio where cif='$_SESSION[cif]'");
			// $cif_perfil->bind_param("i", $cif);
			$cif_perfil->bind_result($cif,$nombre, $usuario,$contraseña,$telefono,$tipo,$foto);
			$cif_perfil->execute();
			$cif_perfil->fetch();

			$this->negocio["cif"]=$cif;
			$this->negocio["nombre"]=$nombre;
			$this->negocio["usuario"]=$usuario;
			$this->negocio["contraseña"]=$contraseña;
			$this->negocio["telefono"]=$telefono;
			$this->negocio["tipo"]=$tipo;
			$this->negocio["foto"]=$foto;

			$cif_perfil->close();

			return $this->negocio;

		}
		
		public function añadir_negocios($cif,$nombre, $usuario,$contraseña,$telefono,$tipo,$imagen){

			if ($imagen['size']>0) {

                if (!file_exists("../../assets/imagenes")) {
                    mkdir("../../assets/imagenes");
                }

                if ($imagen["type"]==="image/jpeg") {
                    $foto=$nombre.".jpg";
                }elseif ($imagen["type"]==="image/png") {
                    $foto=$nombre.".png";
                }
			
                $ruta="../../assets/imagenes/$foto";

                move_uploaded_file ($imagen['tmp_name'],$ruta);

			}

			$insertar_negocio= $this->bd->prepare("INSERT into negocio values (?,?,?,?,?,?,?)");
			$insertar_negocio->bind_param("isssiss", $cif,$nombre, $usuario,$contraseña,$telefono,$tipo,$foto);
			$insertar_negocio->execute();

			$insertar_negocio->close();

		}

		public function buscar_cif($cif){

			$cif_busc = $this->bd->prepare("SELECT * from negocio where cif=?");
			$cif_busc->bind_param("i", $cif);
			$cif_busc->bind_result($cif,$nombre, $usuario,$contraseña,$telefono,$tipo,$foto);
			$cif_busc->execute();
			$cif_busc->fetch();

			$this->negocio["cif"]=$cif;
			$this->negocio["nombre"]=$nombre;
			$this->negocio["usuario"]=$usuario;
			$this->negocio["contraseña"]=$contraseña;
			$this->negocio["telefono"]=$telefono;
			$this->negocio["tipo"]=$tipo;
			$this->negocio["foto"]=$foto;

			$cif_busc->close();

			return $this->negocio;

		}

		public function editar_negocios($cif,$nombre, $usuario,$contraseña,$telefono,$tipo,$foto){

			$editar_negocio=$this->bd->prepare("UPDATE negocio set nombre=?, usuario=?, contraseña=?, telefono=?, foto=? where cif=$cif and foto='$foto'");

			$editar_negocio->bind_param("sssis",$nombre,$usuario,$contraseña,$telefono,$foto);
			$editar_negocio->execute();
			$editar_negocio->close();

		}

		// Eventos del negocio
		public function eventneg($cif){

			$datos_evento=$this->bd->query("SELECT * from evento where cif=$cif ");
			while($filas=$datos_evento->fetch_assoc()){

				$this->eventos[]=$filas;

			}

			return $this->eventos;

		}

		// Borrar negocio
		public function borrar_negocio($cif,$nombre, $usuario,$contraseña,$telefono,$tipo,$foto){

            $borrar=$this->bd->prepare("DELETE from negocio where cif=$cif");
            $borrar->bind_param($cif,$nombre, $usuario,$contraseña,$telefono,$tipo,$foto);
            $borrar->execute();

            $borrar->close();

        }

	}
?>