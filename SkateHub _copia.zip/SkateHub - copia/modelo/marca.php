<?php

	require_once("bd.php");

	class modelo_marcas{
		private $bd;
		private $marcas;
	
		public function __construct(){
		
			$this->bd=conexiones::conectar();
		}

		public function get_marcas(){
			
			$consulta=$this->bd->query("SELECT * from marca ");

			while($filas=$consulta->fetch_assoc()){

				$this->marcas[]=$filas;

			}

			$consulta->close();

			return $this->marcas;
		}

		public function añadir_marcas($foto,$nombre){	
			
			if ($foto['size']>0) {

                if (!file_exists("../../assets/imagenes")) {
                    mkdir("../../assets/imagenes");
                }

                if ($foto["type"]==="image/jpeg") {
                    $logotipo=$nombre.".jpg";
                }elseif ($foto["type"]==="image/png") {
                    $logotipo=$nombre.".png";
                }
			
                $ruta="../../assets/imagenes/$logotipo";

                move_uploaded_file ($foto['tmp_name'],$ruta);

			}

			$insertar_marca= $this->bd->prepare("INSERT into marca values (null,?,?)");
			$insertar_marca->bind_param("ss", $logotipo,$nombre);
			$insertar_marca->execute();

			$insertar_marca->close();

		}

		public function carrousel_marc(){

			$consulta=$this->bd->query("SELECT * from marca order by nombre DESC limit 0,3");
									
			while($filas=$consulta->fetch_assoc()){

				$this->marcas[]=$filas;

			}

			$consulta->close();

			return $this->marcas;
			
		}

		// Borrar marca
		// public function borrar_marca($codigo,$logotipo,$nombre){

        //     $borrar=$this->bd->prepare("DELETE from marca where codigo=?");
        //     $borrar->bind_param($codigo,$logotipo,$nombre);
        //     $borrar->execute();

        //     $borrar->close();

        // }

	}
?>