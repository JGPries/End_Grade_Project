<?php

	require_once("bd.php");

	class modelo_deportista{
		private $bd;
		private $deportista;
	
		public function __construct(){
		
			$this->bd=conexiones::conectar();
		}

		public function get_deportista(){
			
			$consulta=$this->bd->query("SELECT * from deportista ");

			while($filas=$consulta->fetch_assoc()){

				$this->deportista[]=$filas;

			}

			$consulta->close();

			return $this->deportista;
		}

		public function perfil_deportista($dni){

			$dni_perfil = $this->bd->prepare("SELECT * from deportista where dni='$_SESSION[dni]'");
			// $dni_perfil->bind_param("i", $dni);
			$dni_perfil->bind_result($dni,$nombre,$apellido,$usuario,$contraseña,$telefono,$fecha,$foto);
			$dni_perfil->execute();
			$dni_perfil->fetch();

			$this->deportista["dni"]=$dni;
			$this->deportista["nombre"]=$nombre;
			$this->deportista["apellido"]=$apellido;
			$this->deportista["usuario"]=$usuario;
			$this->deportista["contraseña"]=$contraseña;
			$this->deportista["telefono"]=$telefono;
			$this->deportista["fecha"]=$fecha;
			$this->deportista["foto"]=$foto;

			$dni_perfil->close();

			return $this->deportista;

		}

		public function añadir_deportistas($dni,$nombre, $apellido,$usuario,$contraseña,$telefono,$fecha,$imagen){

			if ($imagen['size']>0) {

                if (!file_exists("../../assets/imagenes")) {
                    mkdir("../../assets/imagenes");
                }

                if ($imagen["type"]==="image/jpeg") {
                    $foto=$nombre.".jpg";
                }elseif ($imagen["type"]==="image/png") {
                    $foto=$nombre.".png";
                }
			
                $ruta="../../assets/imagenes/$foto";

                move_uploaded_file ($imagen['tmp_name'],$ruta);

			}

			$insertar_deportista= $this->bd->prepare("INSERT into deportista values (?,?,?,?,?,?,?,?)");
			$insertar_deportista->bind_param("issssiss", $dni,$nombre, $apellido,$usuario,$contraseña,$telefono,$fecha,$foto);
			$insertar_deportista->execute();
			$insertar_deportista->close();

		}

		public function buscar_dni($dni){

			$dni_busc = $this->bd->prepare("SELECT * from deportista where dni=?");
			$dni_busc->bind_param("i", $dni);
			$dni_busc->bind_result($dni,$nombre, $apellido,$usuario,$contraseña,$telefono,$fecha,$foto);
			$dni_busc->execute();
			$dni_busc->fetch();

			$this->deportista["dni"]=$dni;
			$this->deportista["nombre"]=$nombre;
			$this->deportista["apellido"]=$apellido;
			$this->deportista["usuario"]=$usuario;
			$this->deportista["contraseña"]=$contraseña;
			$this->deportista["telefono"]=$telefono;
			$this->deportista["fecha"]=$fecha;
			$this->deportista["foto"]=$foto;

			$dni_busc->close();

			return $this->deportista;

		}

		public function editar_deportistas($dni,$nombre,$apellido,$usuario,$contraseña,$telefono,$fecha,$foto){

			$editar_deportista=$this->bd->prepare("UPDATE deportista set nombre=?,apellido=?, usuario=?, contraseña=?, telefono=?, fecha=?, foto=? where dni=$dni and foto='$foto'");

			$editar_deportista->bind_param("ssssiss",$nombre,$apellido,$usuario,$contraseña,$telefono,$fecha,$foto);
			$editar_deportista->execute();
			$editar_deportista->close();

		}

		// Borrar deportista
		public function borrar_deportista($dni,$nombre,$apellido,$usuario,$contraseña,$telefono,$fecha,$foto){

            $borrar=$this->bd->prepare("DELETE from deportista where dni=$dni");
            $borrar->bind_param($dni,$nombre,$apellido,$usuario,$contraseña,$telefono,$fecha,$foto);
            $borrar->execute();

            $borrar->close();

        }

	}
?>