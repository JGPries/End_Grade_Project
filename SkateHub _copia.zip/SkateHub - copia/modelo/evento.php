<?php

	require_once("bd.php");

	class modelo_evento{
		private $bd;
		private $eventos;

		public function __construct(){
		
			$this->bd=conexiones::conectar();
		}

		public function get_eventos(){

			$datos_evento=$this->bd->query("SELECT * from evento ");
			while($filas=$datos_evento->fetch_assoc()){

				$this->eventos[]=$filas;

			}

			return $this->eventos;

		}

		public function añadir_eventos($cif,$nombre,$imagen,$descripción,$fecha){

			if ($imagen['size']>0) {

                if (!file_exists("../../assets/imagenes")) {
                    mkdir("../../assets/imagenes");
                }

                if ($imagen["type"]==="image/jpeg") {
                    $foto=$nombre.".jpg";
                }elseif ($imagen["type"]==="image/png") {
                    $foto=$nombre.".png";
                }
			
                $ruta="../../assets/imagenes/$foto";

                move_uploaded_file ($imagen['tmp_name'],$ruta);

			}

			$insertar_evento= $this->bd->prepare("INSERT into evento values (null,?,?,?,?,?)");
			$insertar_evento->bind_param("sssss",$cif,$nombre,$foto,$descripción,$fecha);
			$insertar_evento->execute();

			$insertar_evento->close();

		}

		// Para elegir un negocio a la hora de crear un evento
		// Ya no le doy uso
		public function selectNegocio(){

            $consulta=$this->bd->query("SELECT cif,nombre from negocio ");
            $i=0;
            while($filaas=$consulta->fetch_assoc()){
                $this->eventos[$i]["cif"]=$filaas['cif'];
                $this->eventos[$i]["nombre"]=$filaas['nombre'];
                $i++;
            }
            $consulta->close();
            return $this->eventos;
        }

		// Para inscribir a un deportista en un evento
		// Ya no le doy uso
		public function selectDeportista(){

            $consulta=$this->bd->query("SELECT dni,nombre from deportista ");
            $i=0;
            while($filaas=$consulta->fetch_assoc()){
                $this->eventos[$i]["dni"]=$filaas['dni'];
                $this->eventos[$i]["nombre"]=$filaas['nombre'];
                $i++;
            }
            $consulta->close();
            return $this->eventos;
        }

		// Buscar el código de un evento para ver más de este
		public function buscar_cod($codigo){

			$busc=$this->bd->prepare("SELECT * from evento where codigo=?");
			$busc->bind_param("i",$codigo);
			$busc->bind_result($codigo,$cif,$nombre,$foto,$descripción,$fecha);
			$busc->execute();
			$busc->fetch();

				$this->eventos["codigo"]=$codigo;
				$this->eventos["cif"]=$cif;
				$this->eventos["nombre"]=$nombre;
				$this->eventos["foto"]=$foto;
				$this->eventos["descripción"]=$descripción;
				$this->eventos["fecha"]=$fecha;

				$busc->close();

				return $this->eventos;

		}

		// Mostrar eventos futuros en el index
		public function ult_eventos(){

			$consulta=$this->bd->query("SELECT * from evento order by fecha DESC limit 0,4");
									
			while($filas=$consulta->fetch_assoc()){

				$this->eventos[]=$filas;

			}

			$consulta->close();

			return $this->eventos;
			
		}

		// Mostrar eventos antiguos en el index
		public function ant_eventos(){

			$consulta=$this->bd->query("SELECT * from evento order by fecha ASC limit 0,4");
									
			while($filas=$consulta->fetch_assoc()){

				$this->eventos[]=$filas;

			}

			$consulta->close();

			return $this->eventos;
			
		}

		// Para mostrar los eventos en el index de la empresa que ha iniciado sesión
		public function eventos_neg($cif){

			$datos_evento=$this->bd->query("SELECT * from evento where cif='$_SESSION[cif]' ");
			while($filas=$datos_evento->fetch_assoc()){

				$this->eventos[]=$filas;

			}

			return $this->eventos;

		}

		public function editar_eventos($codigo,$cif,$nombre,$foto,$descripción,$fecha){

			$editar_evento=$this->bd->prepare("UPDATE evento set nombre=?, descripción=?,fecha=? where codigo=$codigo cif=$cif and foto='$foto'");

			$editar_evento->bind_param("ss",$nombre,$descripción);
			$editar_evento->execute();
			$editar_evento->close();

		}

		// Borrar evento
		public function borrar_evento($codigo,$cif,$nombre,$foto,$descripción,$fecha){

            $borrar=$this->bd->prepare("DELETE from evento where codigo=$codigo");
            $borrar->bind_param($codigo,$cif,$nombre,$foto,$descripción,$fecha);
            $borrar->execute();

            $borrar->close();

        }

	}

?>
