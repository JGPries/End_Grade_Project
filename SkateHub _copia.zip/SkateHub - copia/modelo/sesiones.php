<?php

	require_once("bd.php");
	class modelo_sesiones{
		private $bd;
		private $sesiones;
	
		public function __construct(){
			
			$this->bd=conexiones::conectar();
		}

		// Sesiones deportistas

		public function validar_cuenta_d($dni,$contraseña,$bloquear){

			$consulta = $this->bd->prepare("SELECT * from deportista where dni=? and contraseña=md5(?)");
			$contraseña=md5($contraseña);
			$consulta->bind_param("is",$dni,$contraseña);
			$consulta->bind_result($dni,$nombre,$usuario,$contraseña);
			$consulta->execute();
			$consulta->store_result();

			$consulta->fetch();

			$_SESSION['dni']=$dni;
			// $_SESSION['usuario']=$usuario;

			if($bloquear){
				$tiempo=time()+60*60*24*30;
			}else{
				$tiempo=0;
			}

			$codificar=session_encode();
			setcookie("sesh",$codificar,$tiempo,"/");

			return $consulta->num_rows();

			$consulta->close();

		}
		
		// Sesiones negocios
		
		public function validar_cuenta_n($cif,$contraseña,$bloquear){

			$consulta = $this->bd->prepare("SELECT * from negocio where cif=? and contraseña=md5(?)");
			$contraseña=md5($contraseña);
			$consulta->bind_param("is",$cif,$contraseña);
			$consulta->bind_result($cif,$nombre,$usuario,$contraseña);
			$consulta->execute();
			$consulta->store_result();

			$consulta->fetch();

			$_SESSION['cif']=$cif;
			// $_SESSION['usuario']=$usuario;

			// booleano
			// $_SESSION['negocio']=true;

			if($bloquear){
				$tiempo=time()+60*60*24*30;
			}else{
				$tiempo=0;
			}

			$codificar=session_encode();
			setcookie("sesh",$codificar,$tiempo,"/");

			return $consulta->num_rows();

			$consulta->close();

		}

	}
?>
