"use strict"

const galeriaE = document.querySelector("#galeriaExt");

(
    async()=>{

        const respuesta = await fetch("https://api.chucknorris.io/jokes/random");
        const datos = await respuesta.json();

        const chuckValue = await datos["value"];
        galeriaE.appendChild(chuckJoke(chuckValue));

})();


const chuckJoke = (json)=>{

    const rowGal = document.createElement("div");
    rowGal.classList.add("text-center");
    rowGal.style.minWidth=450+'px';
    rowGal.style.marginBottom=5+'%';

    const norris1 = document.createElement("h2");
    norris1.innerText=json;
    rowGal.appendChild(norris1);

    return rowGal;

}