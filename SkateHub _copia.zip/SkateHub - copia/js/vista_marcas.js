"use strict"

// coger las cartas de las marcas por codigo
const cMarcas = document.querySelector("#cartaMarcas");

const nuevaMarca = (dios) =>{

    const rowCarta = document.createElement("div");
    rowCarta.classList.add("row1","marcs");

    const colCarta = document.createElement("div");
    colCarta.classList.add("col");
    rowCarta.appendChild(colCarta);

    const divCarta = document.createElement("div");
    divCarta.classList.add("card","my-5");
    colCarta.appendChild(divCarta);

    const portada = document.createElement("img");
    portada.src= "../../assets/imagenes/"+dios['logotipo'];
    portada.classList.add("card-img-top");
    divCarta.appendChild(portada);

    const cuerpoCarta = document.createElement("div");
    cuerpoCarta.classList.add("card-body");
    divCarta.appendChild(cuerpoCarta);

    const tituloCarta = document.createElement("h4");
    tituloCarta.classList.add("card-title");
    tituloCarta.innerText = dios["nombre"];
    cuerpoCarta.appendChild(tituloCarta);

    return rowCarta;

}

const logotipo = document.querySelector("#logotipo");
const nombre = document.querySelector("#nombre");

// Ajustes para que aparezca el formulario de añadir o quitarlo

const finalM = document.querySelector("#nuevo");

const formAñadir = document.querySelector("#insertar_f");

const añadirB = document.querySelector("#btnAñadir");
if(añadirB!=null){

    añadirB.addEventListener("click",
        ()=>{
            if(formAñadir.classList.contains("d-none")){
                formAñadir.classList.remove("d-none");
                añadirB.value="Cancelar";
            }else{
                formAñadir.classList.add("d-none");
                añadirB.value="Añadir marca";
            }
        }
    );
}


if(sessionStorage.length === 0){
    
    (async()=>{

        const respuesta = await fetch("marcasConfig.php");

        const marca = await respuesta.json();
        console.log("marca");
 
        marca.forEach(
            (algo)=>{
                sessionStorage.setItem("ID_"+algo["nombre"].toUpperCase().replaceAll(" ",""),JSON.stringify(algo));
              
            }
        )

        Object.values(sessionStorage).forEach(
            (algo)=>{
                cMarcas.appendChild(nuevaMarca(JSON.parse(algo)));
            }
        )

    })();

}else{

    Object.values(sessionStorage).forEach(
        (algo)=>{
            cMarcas.appendChild(nuevaMarca(JSON.parse(algo)));
        }
    )

}

const marc = document.querySelectorAll(".marcs");

const lazy = new IntersectionObserver(
    dios=>{
        dios.forEach(
            (dio)=>{
                if(dio.isIntersecting){
                    dio.target.classList.add("sombra");
                }
            }
        )
    }
)

marc.forEach(
    (marca)=>{
        lazy.observe(marca)
    }
)